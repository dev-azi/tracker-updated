from flask import Flask, render_template, request, redirect, url_for, flash, get_flashed_messages
import mysql.connector
from dotenv import load_dotenv
import os
from mysql.connector.errors import IntegrityError

load_dotenv() 
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'fallback_secret_key_for_development')

def get_db_connection():
    return mysql.connector.connect(
        host=os.getenv('DB_HOST'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD'),
        database=os.getenv('DB_NAME')
    )

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/attendance', methods=['GET', 'POST'])
def attendance():
    db = get_db_connection()
    cursor = db.cursor()
    if request.method == 'POST':
        # Handle form submission from modal
        return redirect(url_for('attendance'))
    cursor.execute("""
        SELECT attendance.id, attendance.student_no, student.student_name, attendance.date, attendance.status
        FROM attendance
        INNER JOIN student ON attendance.student_no = student.student_no
    """)
    data = cursor.fetchall()  # Fetch the latest data from the database
    cursor.execute("SELECT id, student_no, student_name FROM student")
    students = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('attendance.html', data=data, students=students)

@app.route('/attendance/add', methods=['POST'])
def add_attendance():
    if request.method == 'POST':
        student_no = request.form.get('student_no') 
        date = request.form.get('date')
        status = request.form.get('status')
        if not student_no or not date or not status:
            flash('All fields are required!', 'danger')
            return redirect(url_for('attendance'))
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("INSERT INTO attendance (student_no, date, status) VALUES (%s, %s, %s)", (student_no, date, status))
        db.commit()
        cursor.close()
        db.close()
        flash('Attendance record successfully added!', 'success')
    return redirect(url_for('attendance'))

@app.route('/attendance/edit/<string:id>', methods=['POST']) 
def edit_attendance(id):
    if request.method == 'POST':
        student_no = request.form.get('student_no') 
        date = request.form.get('date')
        status = request.form.get('status')
        if not student_no or not date or not status:
            flash('All fields are required!', 'danger')
            return redirect(url_for('attendance'))
        db = get_db_connection()
        cursor = db.cursor()
        try:
            cursor.execute(
                "UPDATE attendance SET student_no=%s, date=%s, status=%s WHERE id=%s",
                (student_no, date, status, id)
            )
            db.commit()  # Ensure changes are committed to the database
            flash('Attendance record successfully updated!', 'success')
        except Exception as e:
            print(f"Error updating attendance: {e}")  # Debugging
            flash('An error occurred while updating the attendance record.', 'danger')
        finally:
            cursor.close()
            db.close()
    return redirect(url_for('attendance'))

@app.route('/attendance/delete/<int:id>')
def delete_attendance(id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("DELETE FROM attendance WHERE id=%s", (id,))
    db.commit()
    cursor.close()
    db.close()
    flash('Attendance record successfully deleted!', 'success')
    return redirect(url_for('attendance'))

@app.route('/exam', methods=['GET', 'POST'])
def exam():
    db = get_db_connection()
    cursor = db.cursor()
    if request.method == 'POST':
        # Handle form submission from modal
        return redirect(url_for('exam'))
    cursor.execute("""
        SELECT exam.id, exam.student_no, exam.score, student.student_name
        FROM exam
        INNER JOIN student ON exam.student_no = student.student_no
    """)
    data = cursor.fetchall()
    cursor.execute("SELECT id, student_no, student_name FROM student")
    students = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('exam.html', data=data, students=students)

@app.route('/exam/add', methods=['POST'])
def add_exam():
    if request.method == 'POST':
        student_no = request.form['student_no']
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("INSERT INTO exam (student_no, score) VALUES (%s, %s)", (student_no, score))
        db.commit()
        cursor.close()
        db.close()
        flash('Exam record successfully added!', 'success')
    return redirect(url_for('exam'))

@app.route('/exam/edit/<string:id>', methods=['POST']) 
def edit_exam(id):
    if request.method == 'POST':
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("UPDATE exam SET score=%s WHERE id=%s", (score, id))
        db.commit()
        cursor.close()
        db.close()
        flash('Exam record successfully updated!', 'success')
    return redirect(url_for('exam'))

@app.route('/exam/delete/<int:id>')
def delete_exam(id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("DELETE FROM exam WHERE id=%s", (id,))
    db.commit()
    cursor.close()
    db.close()
    flash('Exam record successfully deleted!', 'success')
    return redirect(url_for('exam'))

@app.route('/quiz', methods=['GET', 'POST'])
def quiz():
    db = get_db_connection()
    cursor = db.cursor()
    if request.method == 'POST':
        # Handle form submission from modal
        return redirect(url_for('quiz'))
    cursor.execute("""
        SELECT quiz.id, quiz.student_no, quiz.score, student.student_name
        FROM quiz
        INNER JOIN student ON quiz.student_no = student.student_no
    """)
    data = cursor.fetchall()
    cursor.execute("SELECT id, student_no, student_name FROM student")
    students = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('quiz.html', data=data, students=students)

@app.route('/quiz/add', methods=['POST'])
def add_quiz():
    if request.method == 'POST':
        student_no = request.form['student_no']
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("INSERT INTO quiz (student_no, score) VALUES (%s, %s)", (student_no, score))
        db.commit()
        cursor.close()
        db.close()
        flash('Quiz record successfully added!', 'success')
    return redirect(url_for('quiz'))

@app.route('/quiz/edit/<string:id>', methods=['POST']) 
def edit_quiz(id):
    if request.method == 'POST':
        score = request.form['score']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("UPDATE quiz SET score=%s WHERE id=%s", (score, id))
        db.commit()
        cursor.close()
        db.close()
        flash('Quiz record successfully updated!', 'success')
    return redirect(url_for('quiz'))

@app.route('/quiz/delete/<int:id>')
def delete_quiz(id):
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("DELETE FROM quiz WHERE id=%s", (id,))
    db.commit()
    cursor.close()
    db.close()
    flash('Quiz record successfully deleted!', 'success')
    return redirect(url_for('quiz'))

@app.route('/student', methods=['GET', 'POST'])
def student():
    db = get_db_connection()
    cursor = db.cursor()
    if request.method == 'POST':
        return redirect(url_for('student'))
    cursor.execute("SELECT * FROM student")
    data = cursor.fetchall()
    cursor.close()
    db.close()
    return render_template('student.html', data=data)

@app.route('/student/add', methods=['POST'])
def add_student():
    if request.method == 'POST':
        student_no = request.form.get('student_no')
        student_name = request.form.get('student_name')
        year_and_section = request.form.get('year_and_section')

        print(f"Adding Student: student_no={student_no}, student_name={student_name}, year_and_section={year_and_section}")

        if not student_no or not student_name or not year_and_section:
            flash('All fields are required!', 'danger')
            return redirect(url_for('student'))

        db = get_db_connection()
        cursor = db.cursor()
        try:
            cursor.execute(
                "INSERT INTO student (student_no, student_name, year_and_section) VALUES (%s, %s, %s)",
                (student_no, student_name, year_and_section)
            )
            db.commit()
            flash('Student record successfully added!', 'success')
        except Exception as e:
            # Debugging: Print the error
            print(f"Error adding student: {e}")
            flash('An error occurred while adding the student.', 'danger')
        finally:
            cursor.close()
            db.close()
    return redirect(url_for('student'))

@app.route('/student/edit/<string:id>', methods=['POST']) 
def edit_student(id):
    if request.method == 'POST':
        student_no = request.form['student_no']
        student_name = request.form['student_name']
        year_and_section = request.form['year_and_section']
        db = get_db_connection()
        cursor = db.cursor()
        cursor.execute("UPDATE student SET student_no=%s, student_name=%s, year_and_section=%s WHERE id=%s", (student_no, student_name, year_and_section, id))
        db.commit()
        cursor.close()
        db.close()
        flash('Student record successfully updated!', 'success')
    return redirect(url_for('student'))

@app.route('/student/delete/<string:id>') 
def delete_student(id):
    db = get_db_connection()
    cursor = db.cursor()
    try:
        cursor.execute("DELETE FROM student WHERE id=%s", (id,))
        db.commit()
        flash('Student record successfully deleted!', 'success') 
    except IntegrityError:
        flash('Cannot delete student record as it is being referenced in other records!', 'danger') 
    finally:
        cursor.close()
        db.close()
    return redirect(url_for('student'))

if __name__ == '__main__':
    app.run(debug=True)
